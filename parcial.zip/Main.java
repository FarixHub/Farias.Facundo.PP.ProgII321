public class Main {
    public static void main(String[] args) {
        AgenciaEspacial agencia = new AgenciaEspacial();

        try {
            Nave naveExploracion = new NaveExploracion("Explorador1", 5, 2022, TipoMision.INVESTIGACION);
            Nave carguero = new Carguero("Galáctica", 8, 2023, 300);
            Nave cruceroEstelar = new CruceroEstelar("Estrella Azul", 100, 2024, 200);

            agencia.agregarNave(naveExploracion);
            agencia.agregarNave(carguero);
            agencia.agregarNave(cruceroEstelar);

            agencia.mostrarNaves();
            agencia.iniciarExploracion();
        } catch (NaveDuplicadaException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}