public class NaveDuplicadaException extends Exception {
    public NaveDuplicadaException(String mensaje) {
        super(mensaje);
    }
}