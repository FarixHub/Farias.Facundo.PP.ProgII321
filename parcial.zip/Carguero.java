public class Carguero extends Nave {
    private int capacidadCarga;

    public Carguero(String nombre, int capacidadTripulacion, int anioLanzamiento, int capacidadCarga) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        if (capacidadCarga < 100 || capacidadCarga > 500) {
            throw new IllegalArgumentException("Capacidad de carga debe estar entre 100 y 500 toneladas.");
        }
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void explorar() {
        System.out.println(nombre + " está iniciando su misión de exploración con carga.");
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Carguero - Nombre: " + nombre + ", Capacidad: " + capacidadTripulacion + ", Año: " + anioLanzamiento + ", Capacidad de Carga: " + capacidadCarga + " toneladas");
    }
}