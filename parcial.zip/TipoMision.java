public enum TipoMision {
    CARTOGRAFIA, INVESTIGACION, CONTACTO
}