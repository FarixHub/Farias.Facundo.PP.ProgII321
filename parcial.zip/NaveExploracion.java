public class NaveExploracion extends Nave {
    private TipoMision tipoMision;

    public NaveExploracion(String nombre, int capacidadTripulacion, int anioLanzamiento, TipoMision tipoMision) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.tipoMision = tipoMision;
    }

    @Override
    public void explorar() {
        System.out.println(nombre + " está realizando una misión de " + tipoMision + ".");
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Nave de Exploración - Nombre: " + nombre + ", Capacidad: " + capacidadTripulacion + ", Año: " + anioLanzamiento + ", Tipo de Misión: " + tipoMision);
    }
}