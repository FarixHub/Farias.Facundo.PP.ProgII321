public class CruceroEstelar extends Nave {
    private int cantidadPasajeros;

    public CruceroEstelar(String nombre, int capacidadTripulacion, int anioLanzamiento, int cantidadPasajeros) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Crucero Estelar - Nombre: " + nombre + ", Capacidad: " + capacidadTripulacion + ", Año: " + anioLanzamiento + ", Pasajeros: " + cantidadPasajeros);
    }
}