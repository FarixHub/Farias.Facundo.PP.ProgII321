import java.util.ArrayList;
import java.util.List;

public class AgenciaEspacial {
    private List<Nave> naves;

    public AgenciaEspacial() {
        naves = new ArrayList<>();
    }

    public void agregarNave(Nave nave) throws NaveDuplicadaException {
        for (Nave n : naves) {
            if (n.getNombre().equals(nave.getNombre()) && n.getAnioLanzamiento() == nave.getAnioLanzamiento()) {
                throw new NaveDuplicadaException("La nave con nombre " + nave.getNombre() + " y año " + nave.getAnioLanzamiento() + " ya existe.");
            }
        }
        naves.add(nave);
    }

    public void mostrarNaves() {
        for (Nave nave : naves) {
            nave.mostrarInfo();
        }
    }

    public void iniciarExploracion() {
        for (Nave nave : naves) {
            if (nave instanceof NaveExploracion || nave instanceof Carguero) {
                nave.explorar();
            } else {
                System.out.println(nave.getNombre() + " no puede participar en misiones de exploración.");
            }
        }
    }
}